import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const scenesTable = pgTable("scenes", {
  id: serial("id").primaryKey(),
  sceneId: text("scene_id").notNull().unique(),
  name: text("name").notNull(),
  area: text("area").notNull(),
  description: text("description"),
  roomCount: integer("room_count"),
  notes: text("notes"),
});

export const insertSceneSchema = createInsertSchema(scenesTable).omit({ id: true });
export type InsertScene = z.infer<typeof insertSceneSchema>;
export type Scene = typeof scenesTable.$inferSelect;
