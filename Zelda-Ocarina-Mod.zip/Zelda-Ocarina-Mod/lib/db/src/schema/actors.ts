import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const actorsTable = pgTable("actors", {
  id: serial("id").primaryKey(),
  actorId: text("actor_id").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull().default("misc"),
  description: text("description"),
  hp: integer("hp"),
  damage: integer("damage"),
  notes: text("notes"),
});

export const insertActorSchema = createInsertSchema(actorsTable).omit({ id: true });
export type InsertActor = z.infer<typeof insertActorSchema>;
export type Actor = typeof actorsTable.$inferSelect;
