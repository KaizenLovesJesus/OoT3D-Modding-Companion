import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const changesTable = pgTable("changes", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  filePath: text("file_path").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull().default("other"),
  status: text("status").notNull().default("planned"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertChangeSchema = createInsertSchema(changesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertChange = z.infer<typeof insertChangeSchema>;
export type Change = typeof changesTable.$inferSelect;
