import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const itemPlacementsTable = pgTable("item_placements", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  sceneId: integer("scene_id"),
  sceneName: text("scene_name"),
  locationName: text("location_name").notNull(),
  locationType: text("location_type").notNull().default("chest"),
  originalItemId: text("original_item_id"),
  replacementItemId: text("replacement_item_id").notNull(),
  originalItemName: text("original_item_name"),
  replacementItemName: text("replacement_item_name").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertItemPlacementSchema = createInsertSchema(itemPlacementsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertItemPlacement = z.infer<typeof insertItemPlacementSchema>;
export type ItemPlacement = typeof itemPlacementsTable.$inferSelect;
