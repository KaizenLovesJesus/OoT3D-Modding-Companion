import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const flagsTable = pgTable("flags", {
  id: serial("id").primaryKey(),
  flagId: text("flag_id").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull().default("misc"),
  description: text("description"),
  defaultValue: integer("default_value"),
  notes: text("notes"),
});

export const insertFlagSchema = createInsertSchema(flagsTable).omit({ id: true });
export type InsertFlag = z.infer<typeof insertFlagSchema>;
export type Flag = typeof flagsTable.$inferSelect;
