import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const dialogEntriesTable = pgTable("dialog_entries", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  messageId: text("message_id").notNull(),
  speaker: text("speaker"),
  originalText: text("original_text"),
  modifiedText: text("modified_text").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertDialogEntrySchema = createInsertSchema(dialogEntriesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDialogEntry = z.infer<typeof insertDialogEntrySchema>;
export type DialogEntry = typeof dialogEntriesTable.$inferSelect;
