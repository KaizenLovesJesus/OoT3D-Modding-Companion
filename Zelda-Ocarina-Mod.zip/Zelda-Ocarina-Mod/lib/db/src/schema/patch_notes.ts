import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const patchNotesTable = pgTable("patch_notes", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  version: text("version").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  releaseDate: text("release_date"),
  published: boolean("published").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertPatchNoteSchema = createInsertSchema(patchNotesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPatchNote = z.infer<typeof insertPatchNoteSchema>;
export type PatchNote = typeof patchNotesTable.$inferSelect;
