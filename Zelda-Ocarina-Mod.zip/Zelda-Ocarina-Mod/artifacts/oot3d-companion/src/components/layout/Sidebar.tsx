import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, FolderOpen, Users, Package, Map, Flag,
  ChevronLeft, ChevronRight, BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useListProjects } from "@workspace/api-client-react";

const NAV_MAIN = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: FolderOpen, label: "Projects", href: "/projects" },
];

const NAV_REFERENCE = [
  { icon: Users, label: "Actors", href: "/reference/actors" },
  { icon: Package, label: "Items", href: "/reference/items" },
  { icon: Map, label: "Scenes", href: "/reference/scenes" },
  { icon: Flag, label: "Flags", href: "/reference/flags" },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [location] = useLocation();
  const { data: projects } = useListProjects();

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 60 : 220 }}
      transition={{ duration: 0.2, ease: "easeInOut" }}
      className="h-screen bg-sidebar border-r border-sidebar-border flex flex-col overflow-hidden shrink-0"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-4 border-b border-sidebar-border min-h-[56px]">
        {collapsed ? (
          <button
            onClick={() => setCollapsed(false)}
            className="w-6 h-6 rounded bg-primary flex items-center justify-center mx-auto hover:bg-primary/90 transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-primary-foreground" />
          </button>
        ) : (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 overflow-hidden"
            >
              <div className="w-6 h-6 rounded bg-primary flex items-center justify-center shrink-0">
                <BookOpen className="w-3.5 h-3.5 text-primary-foreground" />
              </div>
              <span className="text-sm font-semibold text-sidebar-foreground truncate">OoT3D Mod</span>
            </motion.div>
            <button
              onClick={() => setCollapsed(true)}
              className="p-1 rounded hover:bg-sidebar-accent text-sidebar-foreground/60 hover:text-sidebar-foreground transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        {NAV_MAIN.map(({ icon: Icon, label, href }) => {
          const active = location === href || (href !== "/" && location.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2.5 px-2 py-2 rounded-md text-sm font-medium transition-colors",
                active
                  ? "bg-sidebar-accent text-primary"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
              )}
              title={collapsed ? label : undefined}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.1 }}
                    className="truncate"
                  >
                    {label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}

        {!collapsed && (
          <div className="pt-4 pb-1 px-2">
            <span className="text-xs font-semibold text-sidebar-foreground/40 uppercase tracking-wider">Reference</span>
          </div>
        )}
        {collapsed && <div className="my-3 border-t border-sidebar-border" />}

        {NAV_REFERENCE.map(({ icon: Icon, label, href }) => {
          const active = location.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2.5 px-2 py-2 rounded-md text-sm font-medium transition-colors",
                active
                  ? "bg-sidebar-accent text-accent"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
              )}
              title={collapsed ? label : undefined}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.1 }}
                    className="truncate"
                  >
                    {label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {!collapsed && (
        <div className="p-3 border-t border-sidebar-border">
          <p className="text-xs text-sidebar-foreground/30 truncate">
            {projects?.length ?? 0} project{projects?.length !== 1 ? "s" : ""}
          </p>
        </div>
      )}
    </motion.aside>
  );
}
