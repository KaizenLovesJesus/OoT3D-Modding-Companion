import { useState } from "react";
import { useParams } from "wouter";
import { motion } from "framer-motion";
import {
  BarChart2, GitCommit, MessageSquare, Package, Layers,
  FileText, BookOpen, Plus, Pencil, Trash2, X, Pin, PinOff,
  CheckCircle2, Clock, RotateCcw, TestTube, AlertCircle
} from "lucide-react";
import {
  useGetProject, useGetProjectStats, useGetProjectActivity,
  useListChanges, useCreateChange, useUpdateChange, useDeleteChange,
  useListNotes, useCreateNote, useUpdateNote, useDeleteNote,
  useListDialogEntries, useCreateDialogEntry, useUpdateDialogEntry, useDeleteDialogEntry,
  useListItemPlacements, useCreateItemPlacement, useUpdateItemPlacement, useDeleteItemPlacement,
  useListAssets, useCreateAsset, useUpdateAsset, useDeleteAsset,
  useListPatchNotes, useCreatePatchNote, useUpdatePatchNote, useDeletePatchNote,
  getListChangesQueryKey, getListNotesQueryKey, getListDialogEntriesQueryKey,
  getListItemPlacementsQueryKey, getListAssetsQueryKey, getListPatchNotesQueryKey,
  getGetProjectStatsQueryKey, getGetProjectActivityQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn, CATEGORY_COLORS, STATUS_COLORS, formatDate, formatRelative } from "@/lib/utils";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis } from "recharts";

const TABS = [
  { id: "overview", label: "Overview", icon: BarChart2 },
  { id: "changes", label: "Changes", icon: GitCommit },
  { id: "dialog", label: "Dialog", icon: MessageSquare },
  { id: "placements", label: "Placements", icon: Package },
  { id: "assets", label: "Assets", icon: Layers },
  { id: "notes", label: "Notes", icon: FileText },
  { id: "patchnotes", label: "Patch Notes", icon: BookOpen },
];

const CHANGE_CATEGORIES = ["gameplay", "audio", "visual", "text", "layout", "logic", "other"];
const CHANGE_STATUSES = ["planned", "in-progress", "done", "testing", "reverted"];
const ASSET_TYPES = ["texture", "model", "audio", "animation", "other"];
const ASSET_STATUSES = ["planned", "in-progress", "done", "testing"];
const LOCATION_TYPES = ["chest", "grotto", "freestanding", "shop", "trade", "minigame", "other"];
const DIALOG_STATUSES = ["pending", "done", "reviewed"];

function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: React.ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-card-border rounded-xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-foreground">{title}</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted text-muted-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

function Badge({ value, colorMap }: { value: string; colorMap: Record<string, string> }) {
  return (
    <span className={cn("text-xs px-2 py-0.5 rounded font-medium capitalize", colorMap[value] || "bg-slate-700/60 text-slate-300")}>
      {value}
    </span>
  );
}

// ---- Overview Tab ----
function OverviewTab({ projectId }: { projectId: number }) {
  const { data: stats } = useGetProjectStats(projectId, { query: { queryKey: getGetProjectStatsQueryKey(projectId) } });
  const { data: activity } = useGetProjectActivity(projectId, { limit: 12 });

  const statusPieData = stats ? Object.entries(stats.changesByStatus).map(([name, value]) => ({ name, value })) : [];
  const categoryBarData = stats ? Object.entries(stats.changesByCategory).map(([name, value]) => ({ name, value })) : [];
  const PIE_COLORS = ["#D4A017", "#14B8A6", "#6366F1", "#EC4899", "#22C55E", "#EF4444"];

  return (
    <div className="space-y-6">
      {stats && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Changes", value: stats.totalChanges, color: "text-amber-400" },
              { label: "Assets", value: stats.totalAssets, color: "text-purple-400" },
              { label: "Dialog", value: stats.totalDialogEntries, color: "text-blue-400" },
              { label: "Placements", value: stats.totalItemPlacements, color: "text-teal-400" },
            ].map(s => (
              <div key={s.label} className="bg-card border border-card-border rounded-lg p-3 text-center">
                <p className={cn("text-2xl font-bold", s.color)}>{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="bg-card border border-card-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Overall Completion</span>
              <span className="text-sm font-bold text-primary">{stats.completionPercentage}%</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${stats.completionPercentage}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="h-full bg-primary rounded-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {statusPieData.length > 0 && (
              <div className="bg-card border border-card-border rounded-lg p-4">
                <p className="text-sm font-medium text-foreground mb-3">Changes by Status</p>
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie data={statusPieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                      {statusPieData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: "hsl(222 40% 11%)", border: "1px solid hsl(220 20% 18%)", borderRadius: "6px", color: "hsl(210 20% 88%)" }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            {categoryBarData.length > 0 && (
              <div className="bg-card border border-card-border rounded-lg p-4">
                <p className="text-sm font-medium text-foreground mb-3">Changes by Category</p>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={categoryBarData} layout="vertical" margin={{ left: 0, right: 10 }}>
                    <XAxis type="number" tick={{ fontSize: 10, fill: "hsl(210 15% 55%)" }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "hsl(210 15% 55%)" }} axisLine={false} tickLine={false} width={55} />
                    <Bar dataKey="value" fill="#D4A017" radius={[0, 3, 3, 0]} />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(222 40% 11%)", border: "1px solid hsl(220 20% 18%)", borderRadius: "6px", color: "hsl(210 20% 88%)" }} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </>
      )}

      {activity && activity.length > 0 && (
        <div className="bg-card border border-card-border rounded-lg">
          <div className="px-4 py-3 border-b border-border">
            <p className="text-sm font-medium text-foreground">Recent Activity</p>
          </div>
          <div className="divide-y divide-border">
            {activity.slice(0, 8).map((item, i) => (
              <div key={item.id} className="flex items-start gap-3 px-4 py-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-foreground line-clamp-1">{item.description}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{formatRelative(item.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---- Changes Tab ----
function ChangesTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListChangesQueryKey(projectId) });
  const [filterCat, setFilterCat] = useState<string | undefined>();
  const [filterStatus, setFilterStatus] = useState<string | undefined>();
  const { data: changes } = useListChanges(projectId, { category: filterCat, status: filterStatus }, { query: { queryKey: getListChangesQueryKey(projectId) } });
  const createChange = useCreateChange({ mutation: { onSuccess: invalidate } });
  const updateChange = useUpdateChange({ mutation: { onSuccess: invalidate } });
  const deleteChange = useDeleteChange({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });

  const [form, setForm] = useState({ filePath: "", description: "", category: "gameplay", status: "planned", notes: "" });

  function openCreate() { setForm({ filePath: "", description: "", category: "gameplay", status: "planned", notes: "" }); setModal({ open: true }); }
  function openEdit(c: any) { setForm({ filePath: c.filePath, description: c.description, category: c.category, status: c.status, notes: c.notes ?? "" }); setModal({ open: true, data: c }); }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (modal.data) updateChange.mutate({ projectId, id: modal.data.id, data: form });
    else createChange.mutate({ projectId, data: form });
    setModal({ open: false });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <select className="bg-input border border-border rounded px-2 py-1 text-xs text-foreground" value={filterCat || ""} onChange={e => setFilterCat(e.target.value || undefined)}>
            <option value="">All Categories</option>
            {CHANGE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select className="bg-input border border-border rounded px-2 py-1 text-xs text-foreground" value={filterStatus || ""} onChange={e => setFilterStatus(e.target.value || undefined)}>
            <option value="">All Statuses</option>
            {CHANGE_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> Add Change
        </button>
      </div>

      {!changes?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <GitCommit className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No changes logged yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {changes.map((c, i) => (
            <motion.div key={c.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
              className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-start gap-3 group"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                  <code className="text-xs text-primary font-mono truncate max-w-[200px]">{c.filePath}</code>
                  <Badge value={c.category} colorMap={CATEGORY_COLORS} />
                  <Badge value={c.status} colorMap={STATUS_COLORS} />
                </div>
                <p className="text-xs text-foreground">{c.description}</p>
                {c.notes && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{c.notes}</p>}
                <p className="text-xs text-muted-foreground mt-1">{formatDate(c.createdAt)}</p>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(c)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => deleteChange.mutate({ projectId, id: c.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <Modal open={modal.open} title={modal.data ? "Edit Change" : "Log Change"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">File Path</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring" placeholder="romfs/actor/player/Link.zsifile" value={form.filePath} onChange={e => setForm(f => ({ ...f, filePath: e.target.value }))} required />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Description</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="What was changed and why?" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Category</label>
              <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                {CHANGE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Status</label>
              <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                {CHANGE_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Notes</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none" rows={2} placeholder="Additional notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Dialog Tab ----
function DialogTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListDialogEntriesQueryKey(projectId) });
  const { data: entries } = useListDialogEntries(projectId, {}, { query: { queryKey: getListDialogEntriesQueryKey(projectId) } });
  const createEntry = useCreateDialogEntry({ mutation: { onSuccess: invalidate } });
  const updateEntry = useUpdateDialogEntry({ mutation: { onSuccess: invalidate } });
  const deleteEntry = useDeleteDialogEntry({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });
  const [form, setForm] = useState({ messageId: "", speaker: "", originalText: "", modifiedText: "", notes: "", status: "pending" });

  function openCreate() { setForm({ messageId: "", speaker: "", originalText: "", modifiedText: "", notes: "", status: "pending" }); setModal({ open: true }); }
  function openEdit(e: any) { setForm({ messageId: e.messageId, speaker: e.speaker ?? "", originalText: e.originalText ?? "", modifiedText: e.modifiedText, notes: e.notes ?? "", status: e.status }); setModal({ open: true, data: e }); }
  function submit(ev: React.FormEvent) {
    ev.preventDefault();
    if (modal.data) updateEntry.mutate({ projectId, id: modal.data.id, data: form });
    else createEntry.mutate({ projectId, data: form });
    setModal({ open: false });
  }

  return (
    <div>
      <div className="flex justify-end mb-3">
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> Add Entry
        </button>
      </div>
      {!entries?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No dialog entries yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {entries.map((e, i) => (
            <motion.div key={e.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
              className="bg-card border border-card-border rounded-lg p-3 group"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <code className="text-xs text-accent font-mono">{e.messageId}</code>
                  {e.speaker && <span className="text-xs text-muted-foreground">— {e.speaker}</span>}
                  <Badge value={e.status} colorMap={STATUS_COLORS} />
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openEdit(e)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => deleteEntry.mutate({ projectId, id: e.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {e.originalText && (
                  <div className="bg-muted/50 rounded p-2">
                    <p className="text-xs text-muted-foreground mb-1">Original</p>
                    <p className="text-xs text-foreground/70">{e.originalText}</p>
                  </div>
                )}
                <div className="bg-primary/10 border border-primary/20 rounded p-2">
                  <p className="text-xs text-primary/70 mb-1">Modified</p>
                  <p className="text-xs text-foreground">{e.modifiedText}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
      <Modal open={modal.open} title={modal.data ? "Edit Dialog Entry" : "New Dialog Entry"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Message ID</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring" placeholder="0x0012" value={form.messageId} onChange={e => setForm(f => ({ ...f, messageId: e.target.value }))} required />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Speaker</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Navi, Zelda..." value={form.speaker} onChange={e => setForm(f => ({ ...f, speaker: e.target.value }))} />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Original Text</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none" rows={2} placeholder="Original game dialog..." value={form.originalText} onChange={e => setForm(f => ({ ...f, originalText: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Modified Text</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none" rows={3} placeholder="Your new dialog..." value={form.modifiedText} onChange={e => setForm(f => ({ ...f, modifiedText: e.target.value }))} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Status</label>
              <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                {DIALOG_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Notes</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Placements Tab ----
function PlacementsTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListItemPlacementsQueryKey(projectId) });
  const { data: placements } = useListItemPlacements(projectId, {}, { query: { queryKey: getListItemPlacementsQueryKey(projectId) } });
  const createPlacement = useCreateItemPlacement({ mutation: { onSuccess: invalidate } });
  const updatePlacement = useUpdateItemPlacement({ mutation: { onSuccess: invalidate } });
  const deletePlacement = useDeleteItemPlacement({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });
  const [form, setForm] = useState({ sceneName: "", locationName: "", locationType: "chest", originalItemName: "", replacementItemName: "", replacementItemId: "0x00", notes: "" });

  function openCreate() { setForm({ sceneName: "", locationName: "", locationType: "chest", originalItemName: "", replacementItemName: "", replacementItemId: "0x00", notes: "" }); setModal({ open: true }); }
  function openEdit(p: any) { setForm({ sceneName: p.sceneName ?? "", locationName: p.locationName, locationType: p.locationType, originalItemName: p.originalItemName ?? "", replacementItemName: p.replacementItemName, replacementItemId: p.replacementItemId, notes: p.notes ?? "" }); setModal({ open: true, data: p }); }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (modal.data) updatePlacement.mutate({ projectId, id: modal.data.id, data: form });
    else createPlacement.mutate({ projectId, data: form });
    setModal({ open: false });
  }

  return (
    <div>
      <div className="flex justify-end mb-3">
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> Add Placement
        </button>
      </div>
      {!placements?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No item placements yet</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Scene</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Location</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Type</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Original</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Replacement</th>
                <th className="py-2 px-3"></th>
              </tr>
            </thead>
            <tbody>
              {placements.map((p, i) => (
                <motion.tr key={p.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                  className="border-b border-border/50 hover:bg-muted/30 transition-colors group"
                >
                  <td className="py-2 px-3 text-muted-foreground">{p.sceneName || "—"}</td>
                  <td className="py-2 px-3 text-foreground font-medium">{p.locationName}</td>
                  <td className="py-2 px-3"><Badge value={p.locationType} colorMap={CATEGORY_COLORS} /></td>
                  <td className="py-2 px-3 text-muted-foreground">{p.originalItemName || "—"}</td>
                  <td className="py-2 px-3 text-primary font-medium">{p.replacementItemName}</td>
                  <td className="py-2 px-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => openEdit(p)} className="p-1 rounded hover:bg-muted text-muted-foreground"><Pencil className="w-3 h-3" /></button>
                      <button onClick={() => deletePlacement.mutate({ projectId, id: p.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive"><Trash2 className="w-3 h-3" /></button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Modal open={modal.open} title={modal.data ? "Edit Placement" : "Add Item Placement"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Scene</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Forest Temple" value={form.sceneName} onChange={e => setForm(f => ({ ...f, sceneName: e.target.value }))} />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Location</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Boss Key Chest" value={form.locationName} onChange={e => setForm(f => ({ ...f, locationName: e.target.value }))} required />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Location Type</label>
            <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.locationType} onChange={e => setForm(f => ({ ...f, locationType: e.target.value }))}>
              {LOCATION_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Original Item</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Boss Key" value={form.originalItemName} onChange={e => setForm(f => ({ ...f, originalItemName: e.target.value }))} />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Replacement Item</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Master Sword" value={form.replacementItemName} onChange={e => setForm(f => ({ ...f, replacementItemName: e.target.value }))} required />
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Assets Tab ----
function AssetsTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListAssetsQueryKey(projectId) });
  const { data: assets } = useListAssets(projectId, {}, { query: { queryKey: getListAssetsQueryKey(projectId) } });
  const createAsset = useCreateAsset({ mutation: { onSuccess: invalidate } });
  const updateAsset = useUpdateAsset({ mutation: { onSuccess: invalidate } });
  const deleteAsset = useDeleteAsset({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });
  const [form, setForm] = useState({ assetPath: "", assetType: "texture", originalFile: "", replacementFile: "", description: "", status: "planned", notes: "" });

  function openCreate() { setForm({ assetPath: "", assetType: "texture", originalFile: "", replacementFile: "", description: "", status: "planned", notes: "" }); setModal({ open: true }); }
  function openEdit(a: any) { setForm({ assetPath: a.assetPath, assetType: a.assetType, originalFile: a.originalFile ?? "", replacementFile: a.replacementFile ?? "", description: a.description ?? "", status: a.status, notes: a.notes ?? "" }); setModal({ open: true, data: a }); }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (modal.data) updateAsset.mutate({ projectId, id: modal.data.id, data: form });
    else createAsset.mutate({ projectId, data: form });
    setModal({ open: false });
  }

  return (
    <div>
      <div className="flex justify-end mb-3">
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> Add Asset
        </button>
      </div>
      {!assets?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <Layers className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No assets tracked yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {assets.map((a, i) => (
            <motion.div key={a.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
              className="bg-card border border-card-border rounded-lg px-4 py-3 flex items-start gap-3 group"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                  <code className="text-xs text-accent font-mono truncate max-w-[200px]">{a.assetPath}</code>
                  <Badge value={a.assetType} colorMap={CATEGORY_COLORS} />
                  <Badge value={a.status} colorMap={STATUS_COLORS} />
                </div>
                {a.description && <p className="text-xs text-foreground">{a.description}</p>}
                {a.replacementFile && <p className="text-xs text-muted-foreground mt-0.5">Replacement: {a.replacementFile}</p>}
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(a)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => deleteAsset.mutate({ projectId, id: a.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
      <Modal open={modal.open} title={modal.data ? "Edit Asset" : "Track Asset"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Asset Path</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring" placeholder="romfs/textures/field/hyrule_field.ctpk" value={form.assetPath} onChange={e => setForm(f => ({ ...f, assetPath: e.target.value }))} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Type</label>
              <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.assetType} onChange={e => setForm(f => ({ ...f, assetType: e.target.value }))}>
                {ASSET_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Status</label>
              <select className="w-full bg-input border border-border rounded px-2 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
                {ASSET_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Replacement File</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring" placeholder="my_custom_texture.png" value={form.replacementFile} onChange={e => setForm(f => ({ ...f, replacementFile: e.target.value }))} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Description</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none" rows={2} placeholder="What does this asset replacement do?" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Notes Tab ----
function NotesTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListNotesQueryKey(projectId) });
  const { data: notes } = useListNotes(projectId, { query: { queryKey: getListNotesQueryKey(projectId) } });
  const createNote = useCreateNote({ mutation: { onSuccess: invalidate } });
  const updateNote = useUpdateNote({ mutation: { onSuccess: invalidate } });
  const deleteNote = useDeleteNote({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });
  const [form, setForm] = useState({ title: "", content: "", tag: "", pinned: false });

  function openCreate() { setForm({ title: "", content: "", tag: "", pinned: false }); setModal({ open: true }); }
  function openEdit(n: any) { setForm({ title: n.title, content: n.content, tag: n.tag ?? "", pinned: n.pinned }); setModal({ open: true, data: n }); }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (modal.data) updateNote.mutate({ projectId, id: modal.data.id, data: form });
    else createNote.mutate({ projectId, data: form });
    setModal({ open: false });
  }
  function togglePin(n: any) { updateNote.mutate({ projectId, id: n.id, data: { pinned: !n.pinned } }); }

  return (
    <div>
      <div className="flex justify-end mb-3">
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> Add Note
        </button>
      </div>
      {!notes?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No notes yet. Capture your ideas.</p>
        </div>
      ) : (
        <div className="columns-1 md:columns-2 gap-3 space-y-3">
          {notes.map((n, i) => (
            <motion.div key={n.id} initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.03 }}
              className="bg-card border border-card-border rounded-lg p-4 group break-inside-avoid"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    {n.pinned && <Pin className="w-3 h-3 text-primary shrink-0" />}
                    <h3 className="text-sm font-semibold text-foreground truncate">{n.title}</h3>
                  </div>
                  {n.tag && <span className="text-xs text-accent">{n.tag}</span>}
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => togglePin(n)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-primary transition-colors">
                    {n.pinned ? <PinOff className="w-3.5 h-3.5" /> : <Pin className="w-3.5 h-3.5" />}
                  </button>
                  <button onClick={() => openEdit(n)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => deleteNote.mutate({ projectId, id: n.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground whitespace-pre-wrap">{n.content}</p>
              <p className="text-xs text-muted-foreground/50 mt-2">{formatRelative(n.updatedAt)}</p>
            </motion.div>
          ))}
        </div>
      )}
      <Modal open={modal.open} title={modal.data ? "Edit Note" : "New Note"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Title</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Note title..." value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Content</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none" rows={4} placeholder="Your note..." value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} />
          </div>
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <label className="text-xs font-medium text-muted-foreground block mb-1">Tag</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="idea, todo, bug..." value={form.tag} onChange={e => setForm(f => ({ ...f, tag: e.target.value }))} />
            </div>
            <label className="flex items-center gap-2 cursor-pointer mt-4">
              <input type="checkbox" checked={form.pinned} onChange={e => setForm(f => ({ ...f, pinned: e.target.checked }))} className="rounded" />
              <span className="text-xs text-muted-foreground">Pin</span>
            </label>
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Patch Notes Tab ----
function PatchNotesTab({ projectId }: { projectId: number }) {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListPatchNotesQueryKey(projectId) });
  const { data: patchNotes } = useListPatchNotes(projectId, { query: { queryKey: getListPatchNotesQueryKey(projectId) } });
  const createPN = useCreatePatchNote({ mutation: { onSuccess: invalidate } });
  const updatePN = useUpdatePatchNote({ mutation: { onSuccess: invalidate } });
  const deletePN = useDeletePatchNote({ mutation: { onSuccess: invalidate } });
  const [modal, setModal] = useState<{ open: boolean; data?: any }>({ open: false });
  const [form, setForm] = useState({ version: "", title: "", content: "", releaseDate: "", published: false });

  function openCreate() { setForm({ version: "", title: "", content: "", releaseDate: "", published: false }); setModal({ open: true }); }
  function openEdit(pn: any) { setForm({ version: pn.version, title: pn.title, content: pn.content, releaseDate: pn.releaseDate ?? "", published: pn.published }); setModal({ open: true, data: pn }); }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (modal.data) updatePN.mutate({ projectId, id: modal.data.id, data: form });
    else createPN.mutate({ projectId, data: form });
    setModal({ open: false });
  }

  return (
    <div>
      <div className="flex justify-end mb-3">
        <button onClick={openCreate} className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors">
          <Plus className="w-3.5 h-3.5" /> New Version
        </button>
      </div>
      {!patchNotes?.length ? (
        <div className="text-center py-12 text-muted-foreground">
          <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No patch notes yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {patchNotes.map((pn, i) => (
            <motion.div key={pn.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
              className="bg-card border border-card-border rounded-lg p-4 group"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-primary font-mono">v{pn.version}</span>
                    <span className="text-sm font-medium text-foreground">{pn.title}</span>
                    {pn.published && <Badge value="published" colorMap={STATUS_COLORS} />}
                  </div>
                  {pn.releaseDate && <p className="text-xs text-muted-foreground mt-0.5">{pn.releaseDate}</p>}
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openEdit(pn)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => deletePN.mutate({ projectId, id: pn.id })} className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground whitespace-pre-wrap leading-relaxed">{pn.content}</p>
            </motion.div>
          ))}
        </div>
      )}
      <Modal open={modal.open} title={modal.data ? "Edit Patch Note" : "New Patch Note"} onClose={() => setModal({ open: false })}>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Version</label>
              <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring" placeholder="1.0.0" value={form.version} onChange={e => setForm(f => ({ ...f, version: e.target.value }))} required />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Release Date</label>
              <input type="date" className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" value={form.releaseDate} onChange={e => setForm(f => ({ ...f, releaseDate: e.target.value }))} />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Title</label>
            <input className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" placeholder="Initial release, Bug fixes..." value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Content</label>
            <textarea className="w-full bg-input border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none font-mono" rows={6} placeholder="- Added new enemy in Forest Temple&#10;- Fixed water temple crash&#10;- Rebalanced boss HP" value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} required />
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.published} onChange={e => setForm(f => ({ ...f, published: e.target.checked }))} className="rounded" />
            <span className="text-xs text-muted-foreground">Mark as published</span>
          </label>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setModal({ open: false })} className="flex-1 px-4 py-2 rounded border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">Save</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ---- Main Workspace ----
export default function ProjectWorkspace() {
  const params = useParams<{ id: string }>();
  const projectId = parseInt(params.id ?? "0");
  const [activeTab, setActiveTab] = useState("overview");
  const { data: project, isLoading } = useGetProject(projectId);

  if (isLoading) return <div className="p-6 text-muted-foreground text-sm">Loading...</div>;
  if (!project) return <div className="p-6 text-muted-foreground text-sm">Project not found</div>;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-foreground">{project.name}</h1>
              <Badge value={project.modType} colorMap={CATEGORY_COLORS} />
              <Badge value={project.status} colorMap={STATUS_COLORS} />
              {project.version && <span className="text-xs text-muted-foreground font-mono">v{project.version}</span>}
            </div>
            {project.description && <p className="text-xs text-muted-foreground mt-0.5">{project.description}</p>}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 border-b border-border">
        <div className="flex gap-1 overflow-x-auto">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition-colors whitespace-nowrap",
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15 }}
        >
          {activeTab === "overview" && <OverviewTab projectId={projectId} />}
          {activeTab === "changes" && <ChangesTab projectId={projectId} />}
          {activeTab === "dialog" && <DialogTab projectId={projectId} />}
          {activeTab === "placements" && <PlacementsTab projectId={projectId} />}
          {activeTab === "assets" && <AssetsTab projectId={projectId} />}
          {activeTab === "notes" && <NotesTab projectId={projectId} />}
          {activeTab === "patchnotes" && <PatchNotesTab projectId={projectId} />}
        </motion.div>
      </div>
    </div>
  );
}
