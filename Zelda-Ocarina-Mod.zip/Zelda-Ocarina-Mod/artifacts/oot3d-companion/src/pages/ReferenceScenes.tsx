import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Map } from "lucide-react";
import { useListScenes, getListScenesQueryKey } from "@workspace/api-client-react";

export default function ReferenceScenes() {
  const [search, setSearch] = useState("");
  const { data: scenes } = useListScenes({ search: search || undefined }, { query: { queryKey: getListScenesQueryKey({ search: search || undefined }) } });

  const grouped = scenes?.reduce((acc, scene) => {
    if (!acc[scene.area]) acc[scene.area] = [];
    acc[scene.area].push(scene);
    return acc;
  }, {} as Record<string, typeof scenes[0][]>) ?? {};

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Scene Reference</h1>
        <p className="text-sm text-muted-foreground mt-0.5">{scenes?.length ?? 0} scenes in database</p>
      </motion.div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          className="w-full bg-input border border-border rounded-md pl-9 pr-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
          placeholder="Search scenes by name or area..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {!scenes?.length ? (
        <div className="text-center py-16 text-muted-foreground">
          <Map className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No scenes found</p>
        </div>
      ) : search ? (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Scene ID</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Name</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Area</th>
                <th className="text-right py-2.5 px-3 text-xs font-semibold text-muted-foreground">Rooms</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Description</th>
              </tr>
            </thead>
            <tbody>
              {scenes.map((scene, i) => (
                <motion.tr key={scene.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.01 }} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                  <td className="py-2.5 px-3"><code className="text-xs text-accent font-mono">{scene.sceneId}</code></td>
                  <td className="py-2.5 px-3 font-medium text-foreground">{scene.name}</td>
                  <td className="py-2.5 px-3 text-muted-foreground">{scene.area}</td>
                  <td className="py-2.5 px-3 text-right text-muted-foreground">{scene.roomCount ?? "—"}</td>
                  <td className="py-2.5 px-3 text-xs text-muted-foreground max-w-xs truncate">{scene.description ?? "—"}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="space-y-4">
          {Object.entries(grouped).sort().map(([area, areaScenes]) => (
            <div key={area} className="bg-card border border-card-border rounded-lg overflow-hidden">
              <div className="px-4 py-2.5 bg-muted/50 border-b border-border">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{area}</h3>
              </div>
              <table className="w-full text-sm">
                <tbody>
                  {areaScenes.map((scene, i) => (
                    <tr key={scene.id} className="border-b border-border/40 last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="py-2.5 px-4 w-20"><code className="text-xs text-accent font-mono">{scene.sceneId}</code></td>
                      <td className="py-2.5 px-4 font-medium text-foreground">{scene.name}</td>
                      <td className="py-2.5 px-4 text-right text-xs text-muted-foreground">{scene.roomCount ? `${scene.roomCount} room${scene.roomCount !== 1 ? "s" : ""}` : ""}</td>
                      <td className="py-2.5 px-4 text-xs text-muted-foreground max-w-xs truncate">{scene.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
