import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Package } from "lucide-react";
import { useListItems, getListItemsQueryKey } from "@workspace/api-client-react";
import { cn, CATEGORY_COLORS } from "@/lib/utils";

const CATEGORIES = ["weapon", "shield", "equipment", "dungeon", "collectible", "quest", "misc"];

export default function ReferenceItems() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>();
  const { data: items } = useListItems({ search: search || undefined, category }, { query: { queryKey: getListItemsQueryKey({ search: search || undefined, category }) } });

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Item Reference</h1>
        <p className="text-sm text-muted-foreground mt-0.5">{items?.length ?? 0} items in database</p>
      </motion.div>

      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            className="w-full bg-input border border-border rounded-md pl-9 pr-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
            placeholder="Search items by name or ID..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select
          className="bg-input border border-border rounded-md px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
          value={category || ""}
          onChange={e => setCategory(e.target.value || undefined)}
        >
          <option value="">All Categories</option>
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {!items?.length ? (
        <div className="text-center py-16 text-muted-foreground">
          <Package className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No items found</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Item ID</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Name</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Category</th>
                <th className="text-left py-2.5 px-3 text-xs font-semibold text-muted-foreground">Description</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, i) => (
                <motion.tr
                  key={item.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.01 }}
                  className="border-b border-border/40 hover:bg-muted/20 transition-colors"
                >
                  <td className="py-2.5 px-3"><code className="text-xs text-accent font-mono">{item.itemId}</code></td>
                  <td className="py-2.5 px-3 font-medium text-foreground">{item.name}</td>
                  <td className="py-2.5 px-3">
                    <span className={cn("text-xs px-2 py-0.5 rounded font-medium capitalize", CATEGORY_COLORS[item.category] || CATEGORY_COLORS.misc)}>
                      {item.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-xs text-muted-foreground">{item.description ?? "—"}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
