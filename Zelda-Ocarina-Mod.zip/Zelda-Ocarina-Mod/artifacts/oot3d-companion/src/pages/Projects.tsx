import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Plus, FolderOpen, ArrowRight, Pencil, Trash2, X } from "lucide-react";
import { useListProjects, useCreateProject, useDeleteProject, useUpdateProject } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListProjectsQueryKey } from "@workspace/api-client-react";
import { cn, CATEGORY_COLORS, STATUS_COLORS, formatDate } from "@/lib/utils";

const MOD_TYPES = ["romhack", "randomizer", "texture", "rebalance", "mixed"];
const STATUSES = ["planning", "in-progress", "testing", "released"];

function ProjectModal({
  open, onClose, initial,
}: {
  open: boolean;
  onClose: () => void;
  initial?: any;
}) {
  const qc = useQueryClient();
  const create = useCreateProject({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListProjectsQueryKey() }); onClose(); } } });
  const update = useUpdateProject({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListProjectsQueryKey() }); onClose(); } } });

  const [form, setForm] = useState({
    name: initial?.name ?? "",
    description: initial?.description ?? "",
    version: initial?.version ?? "0.1",
    modType: initial?.modType ?? "mixed",
    status: initial?.status ?? "planning",
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (initial) {
      update.mutate({ id: initial.id, data: form });
    } else {
      create.mutate({ data: form });
    }
  }

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-card border border-card-border rounded-xl p-6 w-full max-w-md shadow-2xl"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-foreground">{initial ? "Edit Project" : "New Project"}</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Project Name</label>
            <input
              className="w-full bg-input border border-border rounded-md px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
              placeholder="My Awesome Mod"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Description</label>
            <textarea
              className="w-full bg-input border border-border rounded-md px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none"
              placeholder="Brief description of your mod..."
              rows={2}
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Version</label>
              <input
                className="w-full bg-input border border-border rounded-md px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                placeholder="0.1"
                value={form.version}
                onChange={e => setForm(f => ({ ...f, version: e.target.value }))}
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Type</label>
              <select
                className="w-full bg-input border border-border rounded-md px-2 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                value={form.modType}
                onChange={e => setForm(f => ({ ...f, modType: e.target.value }))}
              >
                {MOD_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Status</label>
              <select
                className="w-full bg-input border border-border rounded-md px-2 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                value={form.status}
                onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              >
                {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">
              Cancel
            </button>
            <button type="submit" className="flex-1 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              {initial ? "Save Changes" : "Create Project"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

export default function Projects() {
  const { data: projects, isLoading } = useListProjects({ query: { queryKey: getListProjectsQueryKey() } });
  const qc = useQueryClient();
  const deleteProject = useDeleteProject({ mutation: { onSuccess: () => qc.invalidateQueries({ queryKey: getListProjectsQueryKey() }) } });
  const [showModal, setShowModal] = useState(false);
  const [editProject, setEditProject] = useState<any>(null);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Projects</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{projects?.length ?? 0} mod project{projects?.length !== 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-1.5 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Project
        </button>
      </motion.div>

      {isLoading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-lg p-4 h-24 animate-pulse" />
          ))}
        </div>
      ) : !projects?.length ? (
        <div className="bg-card border border-dashed border-border rounded-xl p-12 text-center">
          <FolderOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-base font-medium text-foreground mb-1">No projects yet</p>
          <p className="text-sm text-muted-foreground mb-4">Start by creating your first mod project</p>
          <button onClick={() => setShowModal(true)} className="inline-flex items-center gap-1.5 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" /> Create Project
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {projects.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="bg-card border border-card-border rounded-lg p-4 group"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm font-semibold text-foreground">{project.name}</h3>
                    <span className={cn("text-xs px-1.5 py-0.5 rounded font-medium", CATEGORY_COLORS[project.modType] || CATEGORY_COLORS.mixed)}>
                      {project.modType}
                    </span>
                    <span className={cn("text-xs px-1.5 py-0.5 rounded font-medium", STATUS_COLORS[project.status] || STATUS_COLORS.planning)}>
                      {project.status}
                    </span>
                    {project.version && (
                      <span className="text-xs text-muted-foreground">v{project.version}</span>
                    )}
                  </div>
                  {project.description && (
                    <p className="text-xs text-muted-foreground line-clamp-1">{project.description}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">Created {formatDate(project.createdAt)}</p>
                </div>
                <div className="flex items-center gap-1 ml-3">
                  <button
                    onClick={() => setEditProject(project)}
                    className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteProject.mutate({ id: project.id })}
                    className="p-1.5 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <Link href={`/projects/${project.id}`} className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-primary transition-colors ml-1">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <ProjectModal open={showModal} onClose={() => setShowModal(false)} />
      {editProject && (
        <ProjectModal open={true} onClose={() => setEditProject(null)} initial={editProject} />
      )}
    </div>
  );
}
