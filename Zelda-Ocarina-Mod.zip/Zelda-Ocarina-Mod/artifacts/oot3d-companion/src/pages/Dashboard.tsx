import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  FolderOpen, Activity, GitCommit, FileText, MessageSquare,
  Package, Layers, ArrowRight, Plus, BookOpen,
} from "lucide-react";
import { useListProjects, useGetProjectStats, useGetProjectActivity } from "@workspace/api-client-react";
import { formatRelative, CATEGORY_COLORS, STATUS_COLORS } from "@/lib/utils";
import { cn } from "@/lib/utils";

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: number | string; color: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-card-border rounded-lg p-4 flex items-center gap-4"
    >
      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", color)}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </motion.div>
  );
}

function ActivityIcon({ type }: { type: string }) {
  const icons: Record<string, any> = {
    change: GitCommit,
    note: FileText,
    dialog: MessageSquare,
    placement: Package,
    asset: Layers,
    patchnote: BookOpen,
  };
  const Icon = icons[type] || Activity;
  return <Icon className="w-3.5 h-3.5" />;
}

function ProjectCard({ project }: { project: any }) {
  const { data: stats } = useGetProjectStats(project.id);
  return (
    <Link
      href={`/projects/${project.id}`}
      className="block bg-card border border-card-border rounded-lg p-4 hover:border-primary/50 transition-colors group"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{project.name}</h3>
          {project.description && (
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{project.description}</p>
          )}
        </div>
        <span className={cn("text-xs px-2 py-0.5 rounded-full font-medium", STATUS_COLORS[project.status] || STATUS_COLORS.planning)}>
          {project.status}
        </span>
      </div>
      <div className="flex items-center gap-3">
        <span className={cn("text-xs px-1.5 py-0.5 rounded font-medium", CATEGORY_COLORS[project.modType] || CATEGORY_COLORS.mixed)}>
          {project.modType}
        </span>
        {stats && (
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">{stats.completionPercentage}%</span>
            </div>
            <div className="h-1 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${stats.completionPercentage}%` }}
              />
            </div>
          </div>
        )}
        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </Link>
  );
}

export default function Dashboard() {
  const { data: projects } = useListProjects();
  const firstProject = projects?.[0];
  const { data: stats } = useGetProjectStats(firstProject?.id ?? 0);
  const { data: activity } = useGetProjectActivity(firstProject?.id ?? 0, { limit: 15 }, {});

  const totalProjects = projects?.length ?? 0;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-0.5">OoT3D Modding Workspace</p>
      </motion.div>

      {/* Summary stats */}
      {firstProject && stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard icon={GitCommit} label="Total Changes" value={stats.totalChanges} color="bg-amber-900/50 text-amber-400" />
          <StatCard icon={Layers} label="Assets" value={stats.totalAssets} color="bg-purple-900/50 text-purple-400" />
          <StatCard icon={MessageSquare} label="Dialog Entries" value={stats.totalDialogEntries} color="bg-blue-900/50 text-blue-400" />
          <StatCard icon={Package} label="Placements" value={stats.totalItemPlacements} color="bg-teal-900/50 text-teal-400" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Projects */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-foreground">Projects</h2>
            <Link href="/projects">
              <a className="text-xs text-primary hover:text-primary/80 flex items-center gap-1">
                View all <ArrowRight className="w-3 h-3" />
              </a>
            </Link>
          </div>

          {!projects?.length ? (
            <div className="bg-card border border-dashed border-border rounded-lg p-8 text-center">
              <FolderOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground mb-3">No projects yet</p>
              <Link href="/projects">
                <a className="inline-flex items-center gap-1.5 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-md font-medium hover:bg-primary/90 transition-colors">
                  <Plus className="w-3 h-3" />
                  Create your first project
                </a>
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {projects.slice(0, 4).map(p => (
                <ProjectCard key={p.id} project={p} />
              ))}
            </div>
          )}
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-sm font-semibold text-foreground mb-3">Recent Activity</h2>
          {!firstProject ? (
            <div className="bg-card border border-dashed border-border rounded-lg p-6 text-center">
              <Activity className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">Activity will appear once you create a project</p>
            </div>
          ) : !activity?.length ? (
            <div className="bg-card border border-dashed border-border rounded-lg p-6 text-center">
              <Activity className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">No activity yet in this project</p>
            </div>
          ) : (
            <div className="bg-card border border-card-border rounded-lg divide-y divide-border">
              {activity.slice(0, 10).map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-start gap-3 px-3 py-2.5"
                >
                  <div className="w-6 h-6 rounded bg-muted flex items-center justify-center shrink-0 mt-0.5 text-muted-foreground">
                    <ActivityIcon type={item.type} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground line-clamp-2">{item.description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{formatRelative(item.createdAt)}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
