import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date) {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(date));
}

export function formatRelative(date: string | Date) {
  const now = new Date();
  const d = new Date(date);
  const diff = now.getTime() - d.getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 30) return formatDate(date);
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return "just now";
}

export const STATUS_COLORS: Record<string, string> = {
  planning: "bg-slate-700/60 text-slate-300",
  "in-progress": "bg-amber-900/50 text-amber-400 border border-amber-700/50",
  testing: "bg-teal-900/50 text-teal-400 border border-teal-700/50",
  released: "bg-green-900/50 text-green-400 border border-green-700/50",
  planned: "bg-slate-700/60 text-slate-300",
  done: "bg-green-900/50 text-green-400 border border-green-700/50",
  reverted: "bg-red-900/50 text-red-400 border border-red-700/50",
  pending: "bg-slate-700/60 text-slate-300",
  reviewed: "bg-teal-900/50 text-teal-400 border border-teal-700/50",
  published: "bg-green-900/50 text-green-400 border border-green-700/50",
};

export const CATEGORY_COLORS: Record<string, string> = {
  gameplay: "bg-purple-900/50 text-purple-400 border border-purple-700/50",
  audio: "bg-blue-900/50 text-blue-400 border border-blue-700/50",
  visual: "bg-pink-900/50 text-pink-400 border border-pink-700/50",
  text: "bg-yellow-900/50 text-yellow-400 border border-yellow-700/50",
  layout: "bg-orange-900/50 text-orange-400 border border-orange-700/50",
  logic: "bg-cyan-900/50 text-cyan-400 border border-cyan-700/50",
  other: "bg-slate-700/60 text-slate-300",
  enemy: "bg-red-900/50 text-red-400 border border-red-700/50",
  npc: "bg-blue-900/50 text-blue-400 border border-blue-700/50",
  object: "bg-slate-700/60 text-slate-300",
  boss: "bg-purple-900/50 text-purple-400 border border-purple-700/50",
  misc: "bg-slate-700/60 text-slate-300",
  weapon: "bg-red-900/50 text-red-400 border border-red-700/50",
  shield: "bg-blue-900/50 text-blue-400 border border-blue-700/50",
  equipment: "bg-amber-900/50 text-amber-400 border border-amber-700/50",
  dungeon: "bg-purple-900/50 text-purple-400 border border-purple-700/50",
  collectible: "bg-yellow-900/50 text-yellow-400 border border-yellow-700/50",
  quest: "bg-teal-900/50 text-teal-400 border border-teal-700/50",
  romhack: "bg-purple-900/50 text-purple-400 border border-purple-700/50",
  randomizer: "bg-amber-900/50 text-amber-400 border border-amber-700/50",
  texture: "bg-pink-900/50 text-pink-400 border border-pink-700/50",
  rebalance: "bg-blue-900/50 text-blue-400 border border-blue-700/50",
  mixed: "bg-teal-900/50 text-teal-400 border border-teal-700/50",
  event: "bg-amber-900/50 text-amber-400 border border-amber-700/50",
  chest: "bg-yellow-900/50 text-yellow-400 border border-yellow-700/50",
  switch: "bg-green-900/50 text-green-400 border border-green-700/50",
  scene: "bg-blue-900/50 text-blue-400 border border-blue-700/50",
  texture_type: "bg-pink-900/50 text-pink-400 border border-pink-700/50",
  model: "bg-purple-900/50 text-purple-400 border border-purple-700/50",
  animation: "bg-cyan-900/50 text-cyan-400 border border-cyan-700/50",
  grotto: "bg-amber-900/50 text-amber-400 border border-amber-700/50",
  freestanding: "bg-green-900/50 text-green-400 border border-green-700/50",
  shop: "bg-yellow-900/50 text-yellow-400 border border-yellow-700/50",
  trade: "bg-teal-900/50 text-teal-400 border border-teal-700/50",
  minigame: "bg-pink-900/50 text-pink-400 border border-pink-700/50",
};
