import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, itemPlacementsTable } from "@workspace/db";
import {
  CreateItemPlacementBody,
  CreateItemPlacementParams,
  UpdateItemPlacementBody,
  UpdateItemPlacementParams,
  DeleteItemPlacementParams,
  ListItemPlacementsParams,
  ListItemPlacementsQueryParams,
  ListItemPlacementsResponse,
  UpdateItemPlacementResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/placements", async (req, res): Promise<void> => {
  const params = ListItemPlacementsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const query = ListItemPlacementsQueryParams.safeParse(req.query);
  const conditions = [eq(itemPlacementsTable.projectId, params.data.projectId)];
  if (query.success && query.data.sceneId) {
    conditions.push(eq(itemPlacementsTable.sceneId, query.data.sceneId));
  }
  const placements = await db.select().from(itemPlacementsTable)
    .where(and(...conditions))
    .orderBy(itemPlacementsTable.sceneName, itemPlacementsTable.locationName);
  res.json(ListItemPlacementsResponse.parse(placements));
});

router.post("/projects/:projectId/placements", async (req, res): Promise<void> => {
  const params = CreateItemPlacementParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateItemPlacementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [placement] = await db.insert(itemPlacementsTable).values({
    projectId: params.data.projectId,
    sceneId: parsed.data.sceneId,
    sceneName: parsed.data.sceneName,
    locationName: parsed.data.locationName,
    locationType: parsed.data.locationType ?? "chest",
    originalItemId: parsed.data.originalItemId,
    replacementItemId: parsed.data.replacementItemId,
    originalItemName: parsed.data.originalItemName,
    replacementItemName: parsed.data.replacementItemName,
    notes: parsed.data.notes,
  }).returning();
  res.status(201).json(placement);
});

router.put("/projects/:projectId/placements/:id", async (req, res): Promise<void> => {
  const params = UpdateItemPlacementParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateItemPlacementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [placement] = await db.update(itemPlacementsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(itemPlacementsTable.id, params.data.id), eq(itemPlacementsTable.projectId, params.data.projectId)))
    .returning();
  if (!placement) {
    res.status(404).json({ error: "Item placement not found" });
    return;
  }
  res.json(UpdateItemPlacementResponse.parse(placement));
});

router.delete("/projects/:projectId/placements/:id", async (req, res): Promise<void> => {
  const params = DeleteItemPlacementParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [placement] = await db.delete(itemPlacementsTable)
    .where(and(eq(itemPlacementsTable.id, params.data.id), eq(itemPlacementsTable.projectId, params.data.projectId)))
    .returning();
  if (!placement) {
    res.status(404).json({ error: "Item placement not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
