import { Router, type IRouter } from "express";
import healthRouter from "./health";
import projectsRouter from "./projects";
import changesRouter from "./changes";
import referenceRouter from "./reference";
import notesRouter from "./notes";
import dialogRouter from "./dialog";
import placementsRouter from "./placements";
import assetsRouter from "./assets";
import patchNotesRouter from "./patchnotes";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectsRouter);
router.use(changesRouter);
router.use(referenceRouter);
router.use(notesRouter);
router.use(dialogRouter);
router.use(placementsRouter);
router.use(assetsRouter);
router.use(patchNotesRouter);
router.use(statsRouter);

export default router;
