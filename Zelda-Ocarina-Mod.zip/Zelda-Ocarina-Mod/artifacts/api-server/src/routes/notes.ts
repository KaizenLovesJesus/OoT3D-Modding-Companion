import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, notesTable } from "@workspace/db";
import {
  CreateNoteBody,
  CreateNoteParams,
  UpdateNoteBody,
  UpdateNoteParams,
  DeleteNoteParams,
  ListNotesParams,
  ListNotesResponse,
  UpdateNoteResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/notes", async (req, res): Promise<void> => {
  const params = ListNotesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const notes = await db.select().from(notesTable)
    .where(eq(notesTable.projectId, params.data.projectId))
    .orderBy(desc(notesTable.pinned), desc(notesTable.updatedAt));
  res.json(ListNotesResponse.parse(notes));
});

router.post("/projects/:projectId/notes", async (req, res): Promise<void> => {
  const params = CreateNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [note] = await db.insert(notesTable).values({
    projectId: params.data.projectId,
    title: parsed.data.title,
    content: parsed.data.content,
    tag: parsed.data.tag,
    pinned: parsed.data.pinned ?? false,
  }).returning();
  res.status(201).json(note);
});

router.put("/projects/:projectId/notes/:id", async (req, res): Promise<void> => {
  const params = UpdateNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [note] = await db.update(notesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(notesTable.id, params.data.id), eq(notesTable.projectId, params.data.projectId)))
    .returning();
  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }
  res.json(UpdateNoteResponse.parse(note));
});

router.delete("/projects/:projectId/notes/:id", async (req, res): Promise<void> => {
  const params = DeleteNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [note] = await db.delete(notesTable)
    .where(and(eq(notesTable.id, params.data.id), eq(notesTable.projectId, params.data.projectId)))
    .returning();
  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
