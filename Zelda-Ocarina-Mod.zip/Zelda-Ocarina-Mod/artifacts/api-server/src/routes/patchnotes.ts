import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, patchNotesTable } from "@workspace/db";
import {
  CreatePatchNoteBody,
  CreatePatchNoteParams,
  UpdatePatchNoteBody,
  UpdatePatchNoteParams,
  DeletePatchNoteParams,
  ListPatchNotesParams,
  ListPatchNotesResponse,
  UpdatePatchNoteResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/patchnotes", async (req, res): Promise<void> => {
  const params = ListPatchNotesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const notes = await db.select().from(patchNotesTable)
    .where(eq(patchNotesTable.projectId, params.data.projectId))
    .orderBy(desc(patchNotesTable.createdAt));
  res.json(ListPatchNotesResponse.parse(notes));
});

router.post("/projects/:projectId/patchnotes", async (req, res): Promise<void> => {
  const params = CreatePatchNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreatePatchNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [note] = await db.insert(patchNotesTable).values({
    projectId: params.data.projectId,
    version: parsed.data.version,
    title: parsed.data.title,
    content: parsed.data.content,
    releaseDate: parsed.data.releaseDate,
    published: parsed.data.published ?? false,
  }).returning();
  res.status(201).json(note);
});

router.put("/projects/:projectId/patchnotes/:id", async (req, res): Promise<void> => {
  const params = UpdatePatchNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdatePatchNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [note] = await db.update(patchNotesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(patchNotesTable.id, params.data.id), eq(patchNotesTable.projectId, params.data.projectId)))
    .returning();
  if (!note) {
    res.status(404).json({ error: "Patch note not found" });
    return;
  }
  res.json(UpdatePatchNoteResponse.parse(note));
});

router.delete("/projects/:projectId/patchnotes/:id", async (req, res): Promise<void> => {
  const params = DeletePatchNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [note] = await db.delete(patchNotesTable)
    .where(and(eq(patchNotesTable.id, params.data.id), eq(patchNotesTable.projectId, params.data.projectId)))
    .returning();
  if (!note) {
    res.status(404).json({ error: "Patch note not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
