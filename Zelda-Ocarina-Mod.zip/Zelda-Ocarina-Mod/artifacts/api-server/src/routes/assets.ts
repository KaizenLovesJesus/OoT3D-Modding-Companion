import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, assetsTable } from "@workspace/db";
import {
  CreateAssetBody,
  CreateAssetParams,
  UpdateAssetBody,
  UpdateAssetParams,
  DeleteAssetParams,
  ListAssetsParams,
  ListAssetsQueryParams,
  ListAssetsResponse,
  UpdateAssetResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/assets", async (req, res): Promise<void> => {
  const params = ListAssetsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const query = ListAssetsQueryParams.safeParse(req.query);
  const conditions = [eq(assetsTable.projectId, params.data.projectId)];
  if (query.success && query.data.type) {
    conditions.push(eq(assetsTable.assetType, query.data.type));
  }
  const assets = await db.select().from(assetsTable)
    .where(and(...conditions))
    .orderBy(assetsTable.assetType, assetsTable.assetPath);
  res.json(ListAssetsResponse.parse(assets));
});

router.post("/projects/:projectId/assets", async (req, res): Promise<void> => {
  const params = CreateAssetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateAssetBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [asset] = await db.insert(assetsTable).values({
    projectId: params.data.projectId,
    assetPath: parsed.data.assetPath,
    assetType: parsed.data.assetType ?? "texture",
    originalFile: parsed.data.originalFile,
    replacementFile: parsed.data.replacementFile,
    description: parsed.data.description,
    status: parsed.data.status ?? "planned",
    notes: parsed.data.notes,
  }).returning();
  res.status(201).json(asset);
});

router.put("/projects/:projectId/assets/:id", async (req, res): Promise<void> => {
  const params = UpdateAssetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateAssetBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [asset] = await db.update(assetsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(assetsTable.id, params.data.id), eq(assetsTable.projectId, params.data.projectId)))
    .returning();
  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  res.json(UpdateAssetResponse.parse(asset));
});

router.delete("/projects/:projectId/assets/:id", async (req, res): Promise<void> => {
  const params = DeleteAssetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [asset] = await db.delete(assetsTable)
    .where(and(eq(assetsTable.id, params.data.id), eq(assetsTable.projectId, params.data.projectId)))
    .returning();
  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
