import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, changesTable } from "@workspace/db";
import {
  CreateChangeBody,
  CreateChangeParams,
  UpdateChangeBody,
  UpdateChangeParams,
  DeleteChangeParams,
  ListChangesParams,
  ListChangesQueryParams,
  ListChangesResponse,
  UpdateChangeResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/changes", async (req, res): Promise<void> => {
  const params = ListChangesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const query = ListChangesQueryParams.safeParse(req.query);
  const conditions = [eq(changesTable.projectId, params.data.projectId)];
  if (query.success && query.data.category) {
    conditions.push(eq(changesTable.category, query.data.category));
  }
  if (query.success && query.data.status) {
    conditions.push(eq(changesTable.status, query.data.status));
  }
  const changes = await db.select().from(changesTable).where(and(...conditions)).orderBy(changesTable.createdAt);
  res.json(ListChangesResponse.parse(changes));
});

router.post("/projects/:projectId/changes", async (req, res): Promise<void> => {
  const params = CreateChangeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateChangeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [change] = await db.insert(changesTable).values({
    projectId: params.data.projectId,
    filePath: parsed.data.filePath,
    description: parsed.data.description,
    category: parsed.data.category ?? "other",
    status: parsed.data.status ?? "planned",
    notes: parsed.data.notes,
  }).returning();
  res.status(201).json(change);
});

router.put("/projects/:projectId/changes/:id", async (req, res): Promise<void> => {
  const params = UpdateChangeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateChangeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [change] = await db.update(changesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(changesTable.id, params.data.id), eq(changesTable.projectId, params.data.projectId)))
    .returning();
  if (!change) {
    res.status(404).json({ error: "Change not found" });
    return;
  }
  res.json(UpdateChangeResponse.parse(change));
});

router.delete("/projects/:projectId/changes/:id", async (req, res): Promise<void> => {
  const params = DeleteChangeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [change] = await db.delete(changesTable)
    .where(and(eq(changesTable.id, params.data.id), eq(changesTable.projectId, params.data.projectId)))
    .returning();
  if (!change) {
    res.status(404).json({ error: "Change not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
