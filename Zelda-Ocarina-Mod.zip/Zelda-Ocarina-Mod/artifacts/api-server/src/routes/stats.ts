import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, changesTable, notesTable, dialogEntriesTable, itemPlacementsTable, assetsTable, patchNotesTable } from "@workspace/db";
import {
  GetProjectStatsParams,
  GetProjectActivityParams,
  GetProjectActivityQueryParams,
  GetProjectStatsResponse,
  GetProjectActivityResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/stats", async (req, res): Promise<void> => {
  const params = GetProjectStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const pid = params.data.projectId;

  const [
    changesAll,
    notesCount,
    dialogCount,
    placementsCount,
    assetsAll,
  ] = await Promise.all([
    db.select().from(changesTable).where(eq(changesTable.projectId, pid)),
    db.select({ count: sql<number>`count(*)` }).from(notesTable).where(eq(notesTable.projectId, pid)),
    db.select({ count: sql<number>`count(*)` }).from(dialogEntriesTable).where(eq(dialogEntriesTable.projectId, pid)),
    db.select({ count: sql<number>`count(*)` }).from(itemPlacementsTable).where(eq(itemPlacementsTable.projectId, pid)),
    db.select().from(assetsTable).where(eq(assetsTable.projectId, pid)),
  ]);

  const changesByStatus: Record<string, number> = {};
  const changesByCategory: Record<string, number> = {};
  for (const c of changesAll) {
    changesByStatus[c.status] = (changesByStatus[c.status] || 0) + 1;
    changesByCategory[c.category] = (changesByCategory[c.category] || 0) + 1;
  }

  const assetsByStatus: Record<string, number> = {};
  const assetsByType: Record<string, number> = {};
  for (const a of assetsAll) {
    assetsByStatus[a.status] = (assetsByStatus[a.status] || 0) + 1;
    assetsByType[a.assetType] = (assetsByType[a.assetType] || 0) + 1;
  }

  const doneChanges = changesAll.filter(c => c.status === "done").length;
  const completionPercentage = changesAll.length > 0
    ? Math.round((doneChanges / changesAll.length) * 100)
    : 0;

  const stats = {
    totalChanges: changesAll.length,
    changesByStatus,
    changesByCategory,
    totalNotes: Number(notesCount[0]?.count ?? 0),
    totalDialogEntries: Number(dialogCount[0]?.count ?? 0),
    totalItemPlacements: Number(placementsCount[0]?.count ?? 0),
    totalAssets: assetsAll.length,
    assetsByStatus,
    assetsByType,
    completionPercentage,
  };

  res.json(GetProjectStatsResponse.parse(stats));
});

router.get("/projects/:projectId/activity", async (req, res): Promise<void> => {
  const params = GetProjectActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const query = GetProjectActivityQueryParams.safeParse(req.query);
  const limit = query.success ? (query.data.limit ?? 20) : 20;
  const pid = params.data.projectId;

  const [changes, notes, dialog, placements, assets, patchNotes] = await Promise.all([
    db.select().from(changesTable).where(eq(changesTable.projectId, pid)).orderBy(sql`${changesTable.createdAt} desc`).limit(limit),
    db.select().from(notesTable).where(eq(notesTable.projectId, pid)).orderBy(sql`${notesTable.createdAt} desc`).limit(limit),
    db.select().from(dialogEntriesTable).where(eq(dialogEntriesTable.projectId, pid)).orderBy(sql`${dialogEntriesTable.createdAt} desc`).limit(limit),
    db.select().from(itemPlacementsTable).where(eq(itemPlacementsTable.projectId, pid)).orderBy(sql`${itemPlacementsTable.createdAt} desc`).limit(limit),
    db.select().from(assetsTable).where(eq(assetsTable.projectId, pid)).orderBy(sql`${assetsTable.createdAt} desc`).limit(limit),
    db.select().from(patchNotesTable).where(eq(patchNotesTable.projectId, pid)).orderBy(sql`${patchNotesTable.createdAt} desc`).limit(limit),
  ]);

  const activity: { id: string; type: string; action: string; description: string; createdAt: Date }[] = [];

  for (const c of changes) {
    activity.push({ id: `change-${c.id}`, type: "change", action: "created", description: `Change tracked: ${c.filePath} — ${c.description}`, createdAt: c.createdAt });
  }
  for (const n of notes) {
    activity.push({ id: `note-${n.id}`, type: "note", action: "created", description: `Note added: ${n.title}`, createdAt: n.createdAt });
  }
  for (const d of dialog) {
    activity.push({ id: `dialog-${d.id}`, type: "dialog", action: "created", description: `Dialog entry: ${d.messageId}${d.speaker ? ` (${d.speaker})` : ""}`, createdAt: d.createdAt });
  }
  for (const p of placements) {
    activity.push({ id: `placement-${p.id}`, type: "placement", action: "created", description: `Item placement: ${p.locationName} → ${p.replacementItemName}`, createdAt: p.createdAt });
  }
  for (const a of assets) {
    activity.push({ id: `asset-${a.id}`, type: "asset", action: "created", description: `Asset tracked: ${a.assetPath} (${a.assetType})`, createdAt: a.createdAt });
  }
  for (const pn of patchNotes) {
    activity.push({ id: `patchnote-${pn.id}`, type: "patchnote", action: "created", description: `Patch note: v${pn.version} — ${pn.title}`, createdAt: pn.createdAt });
  }

  activity.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  res.json(GetProjectActivityResponse.parse(activity.slice(0, limit)));
});

export default router;
