import { Router, type IRouter } from "express";
import { ilike, eq, or } from "drizzle-orm";
import { db, actorsTable, itemsTable, scenesTable, flagsTable } from "@workspace/db";
import {
  ListActorsQueryParams,
  ListActorsResponse,
  ListItemsQueryParams,
  ListItemsResponse,
  ListScenesQueryParams,
  ListScenesResponse,
  ListFlagsQueryParams,
  ListFlagsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/reference/actors", async (req, res): Promise<void> => {
  const query = ListActorsQueryParams.safeParse(req.query);
  let actors;
  if (query.success && query.data.search) {
    actors = await db.select().from(actorsTable).where(
      or(
        ilike(actorsTable.name, `%${query.data.search}%`),
        ilike(actorsTable.actorId, `%${query.data.search}%`),
      )
    );
  } else if (query.success && query.data.category) {
    actors = await db.select().from(actorsTable).where(eq(actorsTable.category, query.data.category));
  } else {
    actors = await db.select().from(actorsTable).orderBy(actorsTable.name);
  }
  const sanitized = actors.map(a => ({
    ...a,
    hp: a.hp ?? undefined,
    damage: a.damage ?? undefined,
    description: a.description ?? undefined,
    notes: a.notes ?? undefined,
  }));
  res.json(ListActorsResponse.parse(sanitized));
});

router.get("/reference/items", async (req, res): Promise<void> => {
  const query = ListItemsQueryParams.safeParse(req.query);
  let items;
  if (query.success && query.data.search) {
    items = await db.select().from(itemsTable).where(
      or(
        ilike(itemsTable.name, `%${query.data.search}%`),
        ilike(itemsTable.itemId, `%${query.data.search}%`),
      )
    );
  } else if (query.success && query.data.category) {
    items = await db.select().from(itemsTable).where(eq(itemsTable.category, query.data.category));
  } else {
    items = await db.select().from(itemsTable).orderBy(itemsTable.name);
  }
  const sanitizedItems = items.map(i => ({
    ...i,
    description: i.description ?? undefined,
    notes: i.notes ?? undefined,
  }));
  res.json(ListItemsResponse.parse(sanitizedItems));
});

router.get("/reference/scenes", async (req, res): Promise<void> => {
  const query = ListScenesQueryParams.safeParse(req.query);
  let scenes;
  if (query.success && query.data.search) {
    scenes = await db.select().from(scenesTable).where(
      or(
        ilike(scenesTable.name, `%${query.data.search}%`),
        ilike(scenesTable.area, `%${query.data.search}%`),
      )
    );
  } else {
    scenes = await db.select().from(scenesTable).orderBy(scenesTable.area, scenesTable.name);
  }
  const sanitizedScenes = scenes.map(s => ({
    ...s,
    description: s.description ?? undefined,
    roomCount: s.roomCount ?? undefined,
    notes: s.notes ?? undefined,
  }));
  res.json(ListScenesResponse.parse(sanitizedScenes));
});

router.get("/reference/flags", async (req, res): Promise<void> => {
  const query = ListFlagsQueryParams.safeParse(req.query);
  let flags;
  if (query.success && query.data.search) {
    flags = await db.select().from(flagsTable).where(
      or(
        ilike(flagsTable.name, `%${query.data.search}%`),
        ilike(flagsTable.flagId, `%${query.data.search}%`),
      )
    );
  } else if (query.success && query.data.type) {
    flags = await db.select().from(flagsTable).where(eq(flagsTable.type, query.data.type));
  } else {
    flags = await db.select().from(flagsTable).orderBy(flagsTable.name);
  }
  const sanitizedFlags = flags.map(f => ({
    ...f,
    description: f.description ?? undefined,
    defaultValue: f.defaultValue ?? undefined,
    notes: f.notes ?? undefined,
  }));
  res.json(ListFlagsResponse.parse(sanitizedFlags));
});

export default router;
