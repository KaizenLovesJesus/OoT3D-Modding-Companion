import { Router, type IRouter } from "express";
import { eq, and, ilike } from "drizzle-orm";
import { db, dialogEntriesTable } from "@workspace/db";
import {
  CreateDialogEntryBody,
  CreateDialogEntryParams,
  UpdateDialogEntryBody,
  UpdateDialogEntryParams,
  DeleteDialogEntryParams,
  ListDialogEntriesParams,
  ListDialogEntriesQueryParams,
  ListDialogEntriesResponse,
  UpdateDialogEntryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/projects/:projectId/dialog", async (req, res): Promise<void> => {
  const params = ListDialogEntriesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const query = ListDialogEntriesQueryParams.safeParse(req.query);
  let entries;
  if (query.success && query.data.search) {
    entries = await db.select().from(dialogEntriesTable).where(
      and(
        eq(dialogEntriesTable.projectId, params.data.projectId),
        ilike(dialogEntriesTable.modifiedText, `%${query.data.search}%`)
      )
    );
  } else {
    entries = await db.select().from(dialogEntriesTable)
      .where(eq(dialogEntriesTable.projectId, params.data.projectId))
      .orderBy(dialogEntriesTable.messageId);
  }
  res.json(ListDialogEntriesResponse.parse(entries));
});

router.post("/projects/:projectId/dialog", async (req, res): Promise<void> => {
  const params = CreateDialogEntryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateDialogEntryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [entry] = await db.insert(dialogEntriesTable).values({
    projectId: params.data.projectId,
    messageId: parsed.data.messageId,
    speaker: parsed.data.speaker,
    originalText: parsed.data.originalText,
    modifiedText: parsed.data.modifiedText,
    notes: parsed.data.notes,
    status: parsed.data.status ?? "pending",
  }).returning();
  res.status(201).json(entry);
});

router.put("/projects/:projectId/dialog/:id", async (req, res): Promise<void> => {
  const params = UpdateDialogEntryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateDialogEntryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [entry] = await db.update(dialogEntriesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(and(eq(dialogEntriesTable.id, params.data.id), eq(dialogEntriesTable.projectId, params.data.projectId)))
    .returning();
  if (!entry) {
    res.status(404).json({ error: "Dialog entry not found" });
    return;
  }
  res.json(UpdateDialogEntryResponse.parse(entry));
});

router.delete("/projects/:projectId/dialog/:id", async (req, res): Promise<void> => {
  const params = DeleteDialogEntryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [entry] = await db.delete(dialogEntriesTable)
    .where(and(eq(dialogEntriesTable.id, params.data.id), eq(dialogEntriesTable.projectId, params.data.projectId)))
    .returning();
  if (!entry) {
    res.status(404).json({ error: "Dialog entry not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
